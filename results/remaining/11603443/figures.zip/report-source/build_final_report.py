"""Create a matched-pair report and figures from audited full-data outputs."""
import argparse
import csv
import json
from pathlib import Path
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def read(p):return json.loads(Path(p).read_text())


def paired_figure(regression,diffusion,output,split,steps,zoom):
    a=np.load(regression/f'{split}_examples.npz')
    b=np.load(diffusion/f'ddim_{steps}/{split}_seed_6180_examples.npz')
    assert np.array_equal(a['row_indices'],b['row_indices'])
    fig,axes=plt.subplots(4,6,figsize=(18,12),layout='constrained')
    for row in range(4):
        y=a['y_over_h'][row];z=a['z_over_h'][row];mask=a['mask'][row]
        for channel in range(2):
            values=[a['truth'][row,channel],a['prediction'][row,channel],b['prediction'][row,channel]]
            vmax=max(np.abs(v[~mask]).max() for v in values)
            for col,value in enumerate(values):
                ax=axes[row,channel*3+col]
                image=ax.pcolormesh(y,z,np.ma.masked_where(mask,value),shading='auto',cmap='RdBu_r',vmin=-vmax,vmax=vmax,rasterized=True)
                ax.set_title(f"row {int(a['row_indices'][row])} · {('Ey','Ez')[channel]} · {('truth','4R regression',f'DDIM-{steps}, seed 6180')[col]}",fontsize=9)
                ax.set_xlabel('y/h');ax.set_ylabel('z/h')
                if zoom:
                    rr,cc=np.where(mask)
                    ax.set_xlim(y[max(0,cc.min()-8)],y[min(len(y)-1,cc.max()+8)])
                    ax.set_ylim(z[max(0,rr.min()-8)],z[min(len(z)-1,rr.max()+8)])
                fig.colorbar(image,ax=ax,shrink=.7)
    name=f"{split}-paired-{'edge' if zoom else 'fields'}.png"
    fig.savefig(output/name,dpi=140);plt.close(fig)


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path,required=True);args=ap.parse_args();repo=args.repo
    original=repo/'results/remaining/11603443';pair=repo/'results/unet_regression/11604740'
    for root in [original,pair]:assert read(root/'validation.json')['status']=='passed'
    r=read(pair/'regression/metrics.json');d=read(pair/'diffusion/metrics.json');cfg=read(pair/'regression/config.json')
    selected=str(d['selected_steps']);timing=d['step_counts'][selected]['batch_one_prediction_seconds'];ratio=timing/r['batch_one_prediction_seconds']
    last_r=json.loads((pair/'regression/history.jsonl').read_text().splitlines()[-1])['epoch']
    last_d=json.loads((pair/'diffusion/history.jsonl').read_text().splitlines()[-1])['epoch']
    keys=['relative_l2','edge_relative_l2','gradient_relative_l2','masked_mse']
    entries=[]
    for name,folder in [('PCA-32 + GP',repo/'results/pca_gp/11601747'),('Plain DeepONet',repo/'results/deeponet_plain/11597463'),('Fourier DeepONet',original/'fourier'),('4R U-Net',pair/'regression')]:
        value=read(folder/'metrics.json')
        for split in ['test','test_extrap']:
            entries.append({'model':name,'split':split,'samples':1,'ddim_steps':0,**{k:value[split][k]['mean'] for k in keys}})
    for name,folder in [('Original direct diffusion',original/'direct'),('Residual diffusion',original/'residual'),('Position-paired diffusion',pair/'diffusion')]:
        value=read(folder/'metrics.json');settings=value['step_counts'][str(value['selected_steps'])]
        for split in ['test','test_extrap']:
            for ensemble in [False,True]:
                values={k:settings[split]['ensemble'][k]['mean'] for k in keys} if ensemble else settings[split]['single_sample_mean']
                entries.append({'model':name,'split':split,'samples':3 if ensemble else 1,'ddim_steps':value['selected_steps'],**values})
    for root in [original,pair]:
        with (root/'comparison.csv').open('w',newline='') as file:
            writer=csv.DictWriter(file,fieldnames=list(entries[0]));writer.writeheader();writer.writerows(entries)
    lines=['# Experiment 4R and matched conditional diffusion','',
           'Deterministic U-Net regression was more accurate than its matched diffusion control on both held-out splits and required one forward pass. This result applies to the recorded architectures, training budgets, and single training seed.','',
           '## Matched comparison','',
           '| Model | Test relative L2 | Extrapolation relative L2 | Test edge L2 | Extrapolation edge L2 |',
           '|---|---:|---:|---:|---:|']
    for name,value in [('4R U-Net',r),('DDIM single draw',None),('DDIM three-draw mean',None)]:
        def v(split,key):
            if value is not None:return value[split][key]['mean']
            s=d['step_counts'][selected][split]
            return s['single_sample_mean'][key] if name=='DDIM single draw' else s['ensemble'][key]['mean']
        lines.append(f"| {name} | {100*v('test','relative_l2'):.2f}% | {100*v('test_extrap','relative_l2'):.2f}% | {100*v('test','edge_relative_l2'):.2f}% | {100*v('test_extrap','edge_relative_l2'):.2f}% |")
    lines+=['',f"Both networks have {r['parameters']:,} parameters and ran sequentially on the same {r['gpu']} in job `11604740`. Actual initialization hashes match: `{cfg['initial_model_sha256']}`. Both receive the same four design parameters and fixed row/column index planes. 4R uses zero field inputs and time zero; the diffusion model receives the noised field and its timestep.",'',
            f"Validation selected {d['selected_steps']} DDIM steps. Single-draw errors average the results for seeds 6180, 6181, and 6182; ensemble errors score the mean of those three fields. Both 20- and 50-step settings, all seeds, and sample variation are retained in the raw outputs.",'',
            '## Compute and selection','',
            '| Model | Training + validation | Last recorded epoch / best | Stop reason | Batch-one prediction |',
            '|---|---:|---:|---|---:|',
            f"| 4R | {r['train_seconds']/3600:.3f} GPU-hours | {last_r} / {r['best_epoch']} | {r['stop_reason']} | {1000*r['batch_one_prediction_seconds']:.2f} ms |",
            f"| Paired DDPM / DDIM-{selected} | {d['train_seconds']/3600:.3f} GPU-hours | {last_d} / {d['best_epoch']} | {d['stop_reason']} | {1000*timing:.2f} ms per draw |",'',
            f"On the same GPU, a diffusion draw cost {ratio:.1f} times as much as the deterministic prediction; a three-draw average cost about {3*ratio:.1f} times as much. Timing uses batch size one, CUDA synchronization, warmups, and repeated calls. It excludes data loading. Training times include validation and checkpoint selection; allocated job wall time including evaluation was 3:04:47.",'',
            '4R selected its EMA checkpoint by validation field MSE and stopped after 30 epochs without improvement. Diffusion selected its EMA checkpoint by fixed-seed validation noise MSE and reached its two-hour training limit. The final diffusion epoch was cut short at the time limit. Equal maximum budgets do not imply equal training durations or convergence. The paired diffusion result should therefore be read as a budgeted comparison, not a claim that further training cannot improve it.','',
            'Targets use means and standard deviations fitted on valid training pixels only. 4R minimizes masked MSE in peak-normalized field units; diffusion minimizes masked noise MSE. Both enforce the known component range [-1,1] at evaluation and zero masked outputs. The recorded clipped and unclipped 4R errors are identical.','',
            '## Relation to the other experiments','',
            'The PCA-32 + GP baseline scored 3.67% / 2.51% relative L2 on test / extrapolation, compared with 2.87% / 1.15% for 4R. Among the recorded models, 4R has the lowest overall field and edge errors on both splits. Residual diffusion with three draws has slightly lower extrapolation gradient error (0.1994 versus 0.2175), while its field and edge errors remain higher.','',
            'The original direct diffusion and residual runs used a V100 and no fixed position planes; they remain separate results. Only the position-conditioned DDPM in this job is the matched backbone control for 4R. Cross-model CPU/GPU timing comparisons are not hardware matched. No test targets were used for model or sampler selection.','',
            '## Fixed examples','',
            'The figures use the first four designs in each fixed split. The diffusion images show seed 6180 at the validation-selected step count; examples were not chosen by error. White cells are excluded trace pixels. Each truth/regression/diffusion group shares its color scale. The full archive also contains prediction-minus-truth figures and all saved example draws.','',
            '![Test fields](test-paired-fields.png)','',
            '![Test edge detail](test-paired-edge.png)','',
            '![Extrapolation fields](test_extrap-paired-fields.png)','',
            '![Extrapolation edge detail](test_extrap-paired-edge.png)','',
            '![Learning curves](learning-curves.png)','',
            '## Files','',
            '- `regression-metrics.json`, `diffusion-metrics.json`, and `comparison.csv`: machine-readable results.',
            '- `regression-results.zip` and `diffusion-results.zip`: full structured outputs, including configurations, histories, per-design metrics, fixed examples, sampler selection, and logs.',
            '- `best-regression.pt` and `best-diffusion.pt`: the selected EMA checkpoints.',
            '- `pair-config.json`, `validation.json`, `provenance.json`, and `sha256sums.txt`: pairing, audit, transfer provenance, and file checksums.',
            '- `figures.zip`: all detailed field/error plots. Optimizer recovery checkpoints remain on HPC.','',
            '[Source and reproduction protocol](../../../experiments/unet_regression/) · [Original diffusion experiments](../../remaining/11603443/)']
    (pair/'README.md').write_text('\n'.join(lines)+'\n')
    for split in ['test','test_extrap']:
        for zoom in [False,True]:paired_figure(pair/'regression',pair/'diffusion',pair,split,d['selected_steps'],zoom)
    fig,axes=plt.subplots(1,3,figsize=(15,4),layout='constrained')
    for ax,folder,title,trainkey,valkey in [(axes[0],pair/'regression','4R: field MSE','train_masked_mse','validation_masked_mse'),(axes[1],pair/'diffusion','Paired DDPM: noise MSE','train_noise_mse','validation_noise_mse'),(axes[2],original/'residual','Residual DDPM: noise MSE','train_noise_mse','validation_noise_mse')]:
        history=[json.loads(x) for x in (folder/'history.jsonl').read_text().splitlines()];metrics=read(folder/'metrics.json')
        for key,label in [(trainkey,'train'),(valkey,'validation')]:ax.plot([x['epoch'] for x in history],[x[key] for x in history],label=label)
        ax.axvline(metrics['best_epoch'],color='gray',linestyle=':',label='selected epoch');ax.set_yscale('log');ax.set_xlabel('epoch');ax.set_title(title);ax.legend(fontsize=8);ax.grid(alpha=.2)
    fig.savefig(pair/'learning-curves.png',dpi=160);plt.close(fig)
    sys.path.insert(0,str(repo/'experiments/remaining'));from build_report import figures
    figures(pair/'regression')
    extra='''\n\n## Interpretation\n\nThe fixed-split field and edge errors do not support paying the sampling cost for diffusion in this comparison. The matched deterministic U-Net in Experiment 4R is more accurate than the direct and residual diffusion variants, including their three-draw averages. Residual diffusion does improve extrapolation gradient error slightly when averaging three draws. The two-hour limit constrained the position-paired diffusion run, and only one training seed was used; these results do not establish that diffusion is intrinsically inferior.\n\n[Matched 4R comparison and complete cross-model table](../../unet_regression/11604740/).\n'''
    with (original/'README.md').open('a') as file:file.write(extra)


if __name__=='__main__':main()
