"""Audit completed HPC outputs against fixed IDs, raw examples, and source provenance."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import h5py
import numpy as np


def read(path):return json.loads(Path(path).read_text())


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--data',required=True)
    args=ap.parse_args();repo=args.repo
    sys.path.insert(0,str(repo/'experiments/remaining'))
    from common import reg,summarize
    roots=[repo/'results/remaining/11603443',repo/'results/unet_regression/11604740']
    keys=['relative_l2','edge_relative_l2','gradient_relative_l2','masked_mse']
    check={'status':'passed','jobs':['11603443','11604740'],'per_design_files':0,'per_design_records':0,'example_files':0,
           'checks':['completed full-data status','exact fixed split IDs and order','aggregate means, medians and standard deviations',
                     'finite examples; masked diffusion and 4R predictions are zero','example truth and grids match original HDF5',
                     'example errors recomputed using original metric code','sampling choices use validation scores',
                     'matching actual initialization hashes and parameter counts for 4R pair','source hashes match the published implementations']}
    for root in roots:
        state=read(root/'status.json');assert state['status']=='complete' and not state['smoke_test_only']
        assert all(v['status']=='complete' for v in state['stages'].values())
        assert not list(root.rglob('last.pt'))
        with h5py.File(args.data) as data:
            for file in sorted(root.rglob('*_per_design.json')):
                split='test_extrap' if file.name.startswith('test_extrap') else 'test'
                expected=read(repo/f'results/pca_gp/11601747/{split}_per_design.json');rows=read(file)
                assert len(rows)==(979 if split=='test_extrap' else 881)
                assert [(v['row_index'],v['sample_id']) for v in rows]==[(v['row_index'],v['sample_id']) for v in expected],file
                assert all(np.isfinite(v[k]) and v[k]>=0 for v in rows for k in keys)
                summary=summarize(rows)
                if '_seed_' in file.name:
                    seed=int(file.name.split('_seed_')[1].split('_')[0]);metric=read(file.parent/'metrics.json')[split]['single_sample_runs'][[6180,6181,6182].index(seed)]
                elif '_ensemble_' in file.name:metric=read(file.parent/'metrics.json')[split]['ensemble']
                else:metric=read(file.parent/'metrics.json')[split]
                for k in keys:
                    for stat in ['mean','median','std']:assert np.isclose(summary[k][stat],metric[k][stat],rtol=1e-6,atol=1e-10),(file,k,stat)
                check['per_design_files']+=1;check['per_design_records']+=len(rows)
                example=file.with_name(file.name.replace('_per_design.json','_examples.npz'))
                ex=np.load(example);ids=ex['row_indices'];assert list(ids)==[v['row_index'] for v in rows[:4]]
                assert np.isfinite(ex['prediction']).all()
                if 'fourier' not in file.relative_to(root).parts:
                    assert (ex['prediction']*ex['mask'][:,None]==0).all()
                for i,index in enumerate(ids):
                    for key in ['truth','mask','y_over_h','z_over_h']:
                        source='u' if key=='truth' else key
                        assert np.array_equal(ex[key][i],data[source][int(index)]),(example,key)
                    actual=reg.design_metrics(ex['prediction'][i],ex['truth'][i],ex['mask'][i],ex['y_over_h'][i],ex['z_over_h'][i])
                    for k in keys:assert np.isclose(actual[k],rows[i][k],rtol=1e-5,atol=1e-9),(example,k)
                check['example_files']+=1
        for cfgfile in root.rglob('config.json'):
            cfg=read(cfgfile)
            for directory,key in [('remaining','source_sha256'),('unet_regression','paired_source_sha256')]:
                for name,expected in cfg.get(key,{}).items():
                    source=repo/f'experiments/{directory}/{name}'
                    assert hashlib.sha256(source.read_bytes()).hexdigest()==expected,(cfgfile,name)
        for file in root.rglob('sampling-selection.json'):
            m=read(file);assert not m['smoke_test_only'];assert m['sample_seeds']==[6180,6181,6182]
            selected=min([20,50],key=lambda n:m['validation_selection'][str(n)]['relative_l2']['mean'])
            assert m['selected_steps']==selected
            full=read(file.parent/'metrics.json')
            for settings in full['step_counts'].values():
                for split in ['test','test_extrap']:
                    s=settings[split]
                    for k in keys:
                        values=[x[k]['mean'] for x in s['single_sample_runs']]
                        assert np.isclose(s['single_sample_mean'][k],np.mean(values))
                        assert np.isclose(s['single_sample_std_across_seeds'][k],np.std(values))
                    assert np.isfinite(s['valid_pixel_sample_variance']) and s['valid_pixel_sample_variance']>=0
    pair=roots[1];a=read(pair/'regression/config.json');b=read(pair/'diffusion/config.json');c=read(pair/'pair-config.json')
    assert a['initial_model_sha256']==b['initial_model_sha256']==c['initial_model_sha256']
    assert a['parameters']==b['parameters']==c['parameters_each']==5_602_322
    check['paired_initial_model_sha256']=a['initial_model_sha256']
    for root in roots:(root/'validation.json').write_text(json.dumps(check,indent=2)+'\n')
    print(json.dumps(check,indent=2))


if __name__=='__main__':main()
